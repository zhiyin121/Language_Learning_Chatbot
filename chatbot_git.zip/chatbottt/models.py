# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
# Unable to inspect table 'arab_voc'
# The error was: list index out of range


class ChVoc(models.Model):
    chid = models.IntegerField(db_column='chID')  # Field name made lowercase.
    chword = models.TextField(db_column='chWord', blank=True, null=True)  # Field name made lowercase.
    engid = models.IntegerField(db_column='engID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'ch_voc'
        unique_together = (('engid', 'chid'),)


class EngVoc(models.Model):
    engid = models.IntegerField(db_column='engID', primary_key=True)  # Field name made lowercase.
    word = models.TextField()
    category = models.TextField()

    class Meta:
        managed = False
        db_table = 'eng_voc'
# Unable to inspect table 'ger_voc'
# The error was: list index out of range
