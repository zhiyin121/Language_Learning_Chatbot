/* extracting the value from the user input from the form in index.html
 * creating a variable 'output' to display the user input
 */
function getUserName() {
var username = document.getElementById('username').value;
var output = document.getElementById('result');
/* checking if user input is greater than 2 characters
 * if greater than 2, displaying user input and redirecting to 'languages.html' after 5 seconds
 */
if (username.length < 2) {
    output.textContent = 'I bet your name has at least 2 characters';
    
} else {
    output.innerHTML = 'Hello ' + username +'!<br><br>'+'Getting started in 3 seconds...';
    var timer = setTimeout(function() {
            window.location='languages.html'
        }, 3000);
}
}



