from django.shortcuts import render
from .models import Arabvoc, Chvoc, Engvoc, Gervoc
from django.template import loader

# Views for all templates 

def index(request):
	return render(request,'chatbot/index.html')
	
def languages(request):
	return render(request,'chatbot/languages.html')

def arabic(request):
	return render(request,'chatbot/arabic.html')
	
def chinese(request):
	return render(request,'chatbot/chinese.html')
	
def german(request):
	return render(request,'chatbot/german.html')
	
# Views for the full word lists
	
def listarab(request):
	arabvoclist = Arabvoc.objects.all() #.get(pk=3001)
	return render(request, 'chatbot/list-arab.html', {'arabvoclist':arabvoclist})
	
def listch(request):
	chvoclist = Chvoc.objects.all()
	return render(request, 'chatbot/list-ch.html', {'chvoclist':chvoclist})
	
def listger(request):
	gervoclist = Gervoc.objects.all()
	return render(request, 'chatbot/list-ger.html', {'gervoclist':gervoclist})
	
# Views for viewing individual words

def vocsarab(request):
	arabcards = Arabvoc.objects.get(pk=3001)
	return render(request,'chatbot/vocs-arab.html', {'arabcards': arabcards})
	
def vocsch(request):
	chcards = Chvoc.objects.get(pk=4001)
	return render(request,'chatbot/vocs-ch.html', {'chcards': chcards})
	
def vocsger(request):
	gercards = Gervoc.objects.get(pk=2001)
	return render(request,'chatbot/vocs-ger.html', {'gercards': gercards})
	
# Views for the vocabulary tests

def testarab(request):
	return render(request,'chatbot/test-arab.html')
	
def testch(request):
	return render(request,'chatbot/test-ch.html')
	
def testger(request):
	return render(request,'chatbot/test-ger.html')
