var x,y;

function submitName(){
x = document.getElementById("nameForm");
y = x.elements["name"].value;
window.location.href = "languages.html";
displayName();
}

function displayName(){
document.getElementById("greeting").innerHTML="Hello" + y + "<br>";
document.getElementById("greeting").innerHTML="Great that you decided to join today!";
}