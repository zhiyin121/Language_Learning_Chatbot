from django.shortcuts import render
# Create your views here.

def home(request):
    return render(request, 'blog/index.html')

def arabic(request):
    return render(request, 'blog/arabic.html')
def chinese(request):
    return render(request, 'blog/chinese.html')
def german(request):
    return render(request, 'blog/german.html')

