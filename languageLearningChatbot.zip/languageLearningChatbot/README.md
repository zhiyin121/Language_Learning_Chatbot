# Language Learning Chatbot

The Language Learnning Chatbot is an application which allows you to learn basic vocabulary in Arabic, Chinese and German.
This application assumes that the user already knows how to pronounce the selected language's alphabet. 

## Getting started

In order to use the chatbot you need to have access to the database. 
You need to have PostgreSQL installed on your computer. Proceed with the following steps:

1. access pgAdmin
2. Create a new Role called 'ptt'. Set the password 'ttws1819' and allow the new role to log in.
3. Create a new database called 'voc2'.
4. Right click on 'voc2' and restore it. Use the file 'voc2-backup'. Now all tables should be in your database in the public schema. Inspect the tables. There should be 14 tables. Four of them are not related to django. They hold the language information. These four tables should have 187 entries each.
5. Set the owner of the database 'voc2' to 'ptt'. If not applied, change the owner of all tables to 'ptt' as well.

To start the application, move to the project directory and execute the following command:
```bash
python manage.py runserver
```

Next, open your browser and type [127.0.0.1:8000/chatbot/](127.0.0.1:8000/chatbot/) (or click on the link).

## Usage

Once you open the application you have to enter your name in order to use the chatbot.
After three seconds you will be redirected to the main page. 
There you are free to choose any of the three languages.

By clicking on any of the given categories you can decide whether you want to see the complete vocabulary list,
go through each word individually or take a vocabulary test to check your knowledge.

## Authors

Olga Stroh,
Amira Sweilem,
Zhiyin Tan,
Hsiao Han Wu
