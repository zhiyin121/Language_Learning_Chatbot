from django.urls import path
from . import views

# create path for the methods in views.py

app_name = 'chatbot'
urlpatterns = [
	path('', views.index, name='index'),
	path('languages.html/',views.languages, name='languages'),
	path('languages.html/arabic.html', views.arabic, name='arabic'),
	path('languages.html/chinese.html/', views.chinese, name='chinese'),
	path('languages.html/german.html/', views.german, name='german'),
	path('languages.html/list-arab.html', views.listarab, name='listarab'),
	path('languages.html/chinese.html/list-ch.html', views.listch, name='listch'),
	path('languages.html/german.html/list-ger.html', views.listger, name='listger'),
	path('languages.html/vocs-arab.html', views.vocsarab, name='vocsarab'),
	path('languages.html/chinese.html/vocs-ch.html', views.vocsch, name='vocsch'),
	path('languages.html/german.html/vocs-ger.html', views.vocsger, name='vocsger'),
	path('languages.html/test-arab.html', views.testarab, name='testarab'),
	path('languages.html/chinese.html/test-ch.html', views.testch, name='testch'),
	path('languages.html/german.html/test-ger.html', views.testger, name='testger'),
]
