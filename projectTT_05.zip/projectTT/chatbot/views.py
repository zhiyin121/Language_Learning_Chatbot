from django.shortcuts import render
from .models import Arabvoc, Chvoc, Engvoc, Gervoc
from django.template import loader
import random

# Views for all basic templates that don't access the database

def index(request):
	return render(request,'chatbot/index.html')
	
def languages(request):
	return render(request,'chatbot/languages.html')

def arabic(request):
	return render(request,'chatbot/arabic.html')
	
def chinese(request):
	return render(request,'chatbot/chinese.html')
	
def german(request):
	return render(request,'chatbot/german.html')
	
''' Views for the vocabulary lists
	storing all words from each table in variables
'''
def listarab(request):
	arabvoclist = Arabvoc.objects.all()
	return render(request, 'chatbot/list-arab.html', {'arabvoclist':arabvoclist})
	
def listch(request):
	chvoclist = Chvoc.objects.all()
	return render(request, 'chatbot/list-ch.html', {'chvoclist':chvoclist})
	
def listger(request):
	gervoclist = Gervoc.objects.all()
	return render(request, 'chatbot/list-ger.html', {'gervoclist':gervoclist})
	
''' Views for viewing individual words (vocabulary cards)
	randomizing the IDs from the tables and storing them in variables
	get objects with the help of the IDs
'''
def vocsarab(request):
	aid = random.randint(3001,3187)
	arabcards = Arabvoc.objects.get(pk=aid)
	return render(request,'chatbot/vocs-arab.html', {'arabcards': arabcards})
	
def vocsch(request):
	cid = random.randint(4001,4187)
	chcards = Chvoc.objects.get(pk=cid)
	return render(request,'chatbot/vocs-ch.html', {'chcards': chcards})
	
def vocsger(request):
	gid = random.randint(2001,2187)
	gercards = Gervoc.objects.get(pk=gid)
	return render(request,'chatbot/vocs-ger.html', {'gercards': gercards})
	
# Views for the vocabulary tests

def testarab(request):
	arabvoclist = Arabvoc.objects.all()
	random_arab = arabvoclist.order_by('?')
	return render(request,'chatbot/test-arab.html',{'random_arab':random_arab})
	
def testch(request):
	return render(request,'chatbot/test-ch.html')
	
def testger(request):
	return render(request,'chatbot/test-ger.html')
