from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('languages/',views.languages, name='languages'),
	path('languages/arabic/', views.arabic, name='arabic'),
	path('languages/chinese/', views.chinese, name='chinese'),
	path('languages/german/', views.german, name='german'),
]
