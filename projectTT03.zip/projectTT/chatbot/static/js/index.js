/* extracts the value from the user input from the form in index.html
 * creates a variable 'output' to display the user input
 */
function getUserName() {
var username = document.getElementById('username').value;
var output = document.getElementById('result');
/* checks if user input is greater than 2 characters
 * if greater than 2, display user input and redirect to 'languages.html' after 5 seconds
 */
if (username.length < 2) {
    output.textContent = 'I bet your name has at least 2 characters';
    
} else {
    output.innerHTML = 'Hello ' + username +'!<br><br>'+'Getting started in 5 seconds...';
    var timer = setTimeout(function() {
            window.location='languages.html'
        }, 5000);
}
}



