from django.shortcuts import render
from .models import Arabvoc, Chvoc, Engvoc, Gervoc
from django.template import loader
import random
import json

#score = 0;
# Views for all basic templates that don't access the database

def index(request):
	#request.session['quiz_count'] = 0
	return render(request,'chatbot/index.html')
	
def languages(request):
	return render(request,'chatbot/languages.html')

def arabic(request):
	return render(request,'chatbot/arabic.html')
	
def chinese(request):
	return render(request,'chatbot/chinese.html')
	
def german(request):
	return render(request,'chatbot/german.html')
	
''' Views for the vocabulary lists
	storing all words from each table in variables
'''
def listarab(request):
	arabvoclist = Arabvoc.objects.all()
	return render(request, 'chatbot/list-arab.html', {'arabvoclist':arabvoclist})
	
def listch(request):
	chvoclist = Chvoc.objects.all()
	return render(request, 'chatbot/list-ch.html', {'chvoclist':chvoclist})
	
def listger(request):
	gervoclist = Gervoc.objects.all()
	return render(request, 'chatbot/list-ger.html', {'gervoclist':gervoclist})
	
''' Views for viewing individual words (vocabulary cards)
	randomizing the IDs from the tables and storing them in variables
	get objects with the help of the IDs
'''
def vocsarab(request):
	aid = random.randint(3001,3187)
	arabcards = Arabvoc.objects.get(pk=aid)
	return render(request,'chatbot/vocs-arab.html', {'arabcards': arabcards})
	
def vocsch(request):
	cid = random.randint(4001,4187)
	chcards = Chvoc.objects.get(pk=cid)
	return render(request,'chatbot/vocs-ch.html', {'chcards': chcards})
	
def vocsger(request):
	gid = random.randint(2001,2187)
	gercards = Gervoc.objects.get(pk=gid)
	return render(request,'chatbot/vocs-ger.html', {'gercards': gercards})
	
''' Views for the vocabulary tests
	randomizing IDs(languages + English words) from database storing them in variables
	get objects with the help of the IDs
'''
def testarab(request):
	is_same = random.randint(0, 1)
	arabvocid = random.randint(3001, 3187)
	arabvoc = Arabvoc.objects.get(pk = arabvocid)
	if is_same == 1:
		engvoc = arabvoc.engid
	else:
		engvocid = random.randint(1, 187)
		engvoc = Engvoc.objects.get(pk = engvocid)
	return render(request,'chatbot/test-arab.html',{'arabvoc': arabvoc, 'engvoc':engvoc, 'isSame': json.dumps(is_same)})
	
def testch(request):
	is_same = random.randint(0, 1)
	chvocid = random.randint(4001, 4187)
	chvoc = Chvoc.objects.get(pk = chvocid)
	if is_same == 1:
		engvoc2 = chvoc.engid
	else:
		engvocid2 = random.randint(1, 187)
		engvoc2 = Engvoc.objects.get(pk = engvocid2)
	return render(request,'chatbot/test-ch.html',{'chvoc': chvoc, 'engvoc2':engvoc2, 'isSame': json.dumps(is_same)})
	
def testger(request):
	#quiz_count = request.session.get('quiz_count', 0)
	#request.session['quiz_count'] = quiz_count + 1	
	#if quiz_count <= 5:
	is_same = random.randint(0, 1)
	gervocid = random.randint(2001, 2187)
	gervoc = Gervoc.objects.get(pk = gervocid)
	if is_same == 1:
		engvoc3 = gervoc.engid
	else:
		engvocid3 = random.randint(1, 187)
		engvoc3 = Engvoc.objects.get(pk = engvocid3)
	return render(request,'chatbot/test-ger.html', {'gervoc': gervoc, 'engvoc3':engvoc3, 'isSame': json.dumps(is_same)})
