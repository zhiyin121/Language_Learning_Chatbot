"""
	views.py tells what's going to happen when certain pages are requested
"""
from django.shortcuts import render
from .models import Arabvoc, Chvoc, Engvoc, Gervoc
import random
import json
"""
	views for all basic templates:
	will open the template without accessing the database
"""
def index(request):
	return render(request,'chatbot/index.html')
	
def languages(request):
	return render(request,'chatbot/languages.html')

def arabic(request):
	return render(request,'chatbot/arabic.html')
	
def chinese(request):
	return render(request,'chatbot/chinese.html')
	
def german(request):
	return render(request,'chatbot/german.html')
''' 
	views for the vocabulary lists:
	storing all words from each table in variables LANGvoclist
	loading them in the templates
'''
def listarab(request):
	arabvoclist = Arabvoc.objects.all()
	return render(request, 'chatbot/list-arab.html', {'arabvoclist':arabvoclist})
	
def listch(request):
	chvoclist = Chvoc.objects.all()
	return render(request, 'chatbot/list-ch.html', {'chvoclist':chvoclist})
	
def listger(request):
	gervoclist = Gervoc.objects.all()
	return render(request, 'chatbot/list-ger.html', {'gervoclist':gervoclist})
	
''' views for viewing individual words (vocabulary cards):
	storing IDs in lst and words in lts2
	to generate random ID, put them into lst
	if an ID already exists in lst, then generate another one
	next, get the words according to the ID in lst, put them into lst2
	json.dumps is a function for transport data from django to js in html (also 'safe' in html file)
'''
def vocsarab(request):
	lst = []
	lst2 = []
	for i in range(187):
		id = random.randint(3001,3187)
		while id in lst:
			id = random.randint(3001, 3187)
		lst.append(id)
	for id in lst:
		arabcards = Arabvoc.objects.get(pk=id)
		lst2.append(arabcards)
	dict = []
	for obj in lst2:
		arab = str(obj.arabword)
		eng = str(obj.engid.engword)
		dict.append((arab, eng))
	return render(request, 'chatbot/vocs-arab.html', {'arabcards': lst2, 'arabcardsdict': json.dumps(dict)})
	
def vocsch(request):
	lst = []
	lst2 = []
	for i in range(187):
		id = random.randint(4001,4187)
		while id in lst:
			id = random.randint(4001, 4187)
		lst.append(id)
	for id in lst:
		chcards = Chvoc.objects.get(pk=id)
		lst2.append(chcards)
	dict = []
	for obj in lst2:
		ch = str(obj.chword)
		eng = str(obj.engid.engword)
		dict.append((ch, eng))
	return render(request, 'chatbot/vocs-ch.html', {'chcards': lst2, 'chcardsdict': json.dumps(dict)})
	
def vocsger(request):
	lst = []
	lst2 = []
	for i in range(187):
		id = random.randint(2001,2187)
		while id in lst:
			id = random.randint(2001, 2187)
		lst.append(id)
	for id in lst:
		gercards = Gervoc.objects.get(pk=id)
		lst2.append(gercards)
	dict = []
	for obj in lst2:
		ger = str(obj.gerword)
		eng = str(obj.engid.engword)
		dict.append((ger, eng))
	return render(request, 'chatbot/vocs-ger.html', {'gercards': lst2, 'gercardsdict': json.dumps(dict)})
	
''' views for the vocabulary tests:
	store randomly generated IDs in lst
	if an IS already exists in lst, then generate another one
	get the words according to the ID in lst, store them into lst2
	next, randomly get 2nd English ID, if it's the same as eng_1, generate another one
	finally, randomize the positions
'''
def testarab(request):
	lst = []
	lst2 = []
	for i in range(11):
		id = random.randint(3001, 3187)
		while id in lst:
			id = random.randint(3001, 3187)
		lst.append(id)
	for id in lst:
		arabtest = Arabvoc.objects.get(pk=id)
		lst2.append(arabtest)
	dict = []
	for obj in lst2:
		ans = random.randint(0, 1)
		arab = str(obj.arabword)
		eng_1 = str(obj.engid.engword)
		randid = random.randint(1, 187) + 3000
		while randid in lst:
			randid = random.randint(1, 187) + 3000
		eng_2 = str(Arabvoc.objects.get(pk=randid).engid.engword)
		if ans == 0:
			dict.append((ans, arab, eng_1, eng_2))
		else:
			dict.append((ans, arab, eng_2, eng_1))
	return render(request, 'chatbot/test-arab.html', {'dict': json.dumps(dict), 'first': dict[0]})
	
def testch(request):
	lst = []
	lst2 = []
	for i in range(11):
		id = random.randint(4001, 4187)
		while id in lst:
			id = random.randint(4001, 4187)
		lst.append(id)
	for id in lst:
		chtest = Chvoc.objects.get(pk=id)
		lst2.append(chtest)
	dict = []
	for obj in lst2:
		ans = random.randint(0, 1)
		ch = str(obj.chword)
		eng_1 = str(obj.engid.engword)
		randid = random.randint(1, 187) + 4000
		while randid in lst:
			randid = random.randint(1, 187) + 4000
		eng_2 = str(Chvoc.objects.get(pk=randid).engid.engword)
		if ans == 0:
			dict.append((ans, ch, eng_1, eng_2))
		else:
			dict.append((ans, ch, eng_2, eng_1))
	return render(request, 'chatbot/test-ch.html', {'dict': json.dumps(dict), 'first': dict[0]})
	
def testger(request):
	lst = []
	lst2 = []
	for i in range(11):
		id = random.randint(2001, 2187)
		while id in lst:
			id = random.randint(2001, 2187)
		lst.append(id)
	for id in lst:
		gertest = Gervoc.objects.get(pk=id)
		lst2.append(gertest)
	dict = []
	for obj in lst2:
		ans = random.randint(0, 1)
		ger = str(obj.gerword)
		eng_1 = str(obj.engid.engword)
		randid = random.randint(1, 187) + 2000
		while randid in lst:
			randid = random.randint(1, 187) + 2000
		eng_2 = str(Gervoc.objects.get(pk=randid).engid.engword)
		if ans == 0:
			dict.append((ans, ger, eng_1, eng_2))
		else:
			dict.append((ans, ger, eng_2, eng_1))
	return render(request, 'chatbot/test-ger.html', {'dict': json.dumps(dict), 'first': dict[0]})
