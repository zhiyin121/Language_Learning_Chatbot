/*create variables to store counts and score*/
var count = 0;
var score = 0;
var output = document.getElementById('result');


/*if function is called in html template
 * call functions addscore and addcount
 * refresh the page*/
function isTrue() {
		addscore();
		addcount();
		window.location.reload();
}

/*if function is called in html template
 * call functions addcount
 * refresh the page*/
function isFalse() {
		addcount();
		window.location.reload();
}
/*if function is called increase score by one*/
function addscore() {
	score = score + 1;
}
/*if function is called
 *increase count by one
 *if count is greater than 5, display result in html template*/
function addcount() {
	count = count + 1;
	if(count == 5) {
		document.getElementById("Result").innerHTML = "Your score is:" + score +"/" + count +"<br>";
	    output.innerHTML = "Your score is:" + score +"/" + count +"<br>";
	}
}




