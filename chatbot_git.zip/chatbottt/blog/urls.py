from django.urls import path
from . import views
urlpatterns = [
    path('',views.home, name = 'blog-index'),
    path('arabic/', views.arabic,name = 'blog-arabic'),
    path('chinese/', views.chinese,name = 'blog-chinese'),
    path('german/', views.german,name = 'blog-german'),
]
