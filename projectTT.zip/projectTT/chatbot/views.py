from django.shortcuts import render
from .models import Arabvoc, Chvoc, Engvoc, Gervoc

# Views for all templates 

def index(request):
	return render(request,'chatbot/index.html')
	
def languages(request):
	return render(request,'chatbot/languages.html')

def arabic(request):
	return render(request,'chatbot/arabic.html')
	
def chinese(request):
	return render(request,'chatbot/chinese.html')
	
def german(request):
	return render(request,'chatbot/german.html')
	
# Views for the full word lists
	
def listarab(request):
	return render(request,'chatbot/list-arab.html')
	
def listch(request):
	return render(request,'chatbot/list-ch.html')
	
def listger(request):
	return render(request,'chatbot/list-ger.html')
	
# Views for viewing individual words

def vocsarab(request):
	return render(request,'chatbot/vocs-arab.html')
	
def vocsch(request):
	return render(request,'chatbot/vocs-ch.html')
	
def vocsger(request):
	return render(request,'chatbot/vocs-ger.html')
	
# Views for the vocabulary tests

def testarab(request):
	return render(request,'chatbot/test-arab.html')
	
def testch(request):
	return render(request,'chatbot/test-ch.html')
	
def testger(request):
	return render(request,'chatbot/test-ger.html')

# TEST
def vote(request, engid):
    eVoc = get_object_or_404(Engvoc, pk=engid)
    try:
        selected_choice = eVoc.arabid.get(pk=request.POST['arabword'])
    except (KeyError, Arabvoc.DoesNotExist):
        # Redisplay the question voting form.
        return render(request, 'chatbot/arab.html', {
            'eVoc': eVoc,
            'error_message': "You didn't select a choice.",
        })
    else:
       
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect(reverse('chatbot:arabic'))
