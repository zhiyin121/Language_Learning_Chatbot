from django.urls import path
from . import views

app_name = 'chatbot'
urlpatterns = [
	path('', views.index, name='index'),
	path('languages.html/',views.languages, name='languages'),
	path('languages.html/arabic.html', views.arabic, name='arabic'),
	path('languages.html/chinese.html/', views.chinese, name='chinese'),
	path('languages.html/german.html/', views.german, name='german'),
	path('languages.html/list-arab.html', views.listarab, name='listarab'),
	path('languages.html/chinese.html/list-ch.html', views.listch, name='listch'),
	path('languages.html/german.html/list-ger.html', views.listger, name='listger'),
	path('languages.html/vocs-arab.html', views.listarab, name='vocsarab'),
	path('languages.html/vocs-ch.html', views.listch, name='vocsch'),
	path('languages.html/vocs-ger.html', views.listger, name='vocsger'),
	path('languages.html/test-arab.html', views.listarab, name='testarab'),
	path('languages.html/test-ch.html', views.listch, name='testch'),
	path('languages.html/test-ger.html', views.listger, name='testger'),
]
