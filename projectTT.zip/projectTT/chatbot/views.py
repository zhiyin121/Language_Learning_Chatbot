from django.shortcuts import render
from .models import Arabvoc, Chvoc, Engvoc, Gervoc
from django.template import loader
from django.db.models.aggregates import Count
from random import randint

# Views for all templates 

def index(request):
	return render(request,'chatbot/index.html')
	
def languages(request):
	return render(request,'chatbot/languages.html')

def arabic(request):
	return render(request,'chatbot/arabic.html')
	
def chinese(request):
	return render(request,'chatbot/chinese.html')
	
def german(request):
	return render(request,'chatbot/german.html')
	
# Views for the full word lists
	
def listarab(request):
	arabvoclist = Arabvoc.objects.all()
	return render(request, 'chatbot/list-arab.html', {'arabvoclist':arabvoclist})
	
def listch(request):
	chvoclist = Chvoc.objects.all()
	return render(request, 'chatbot/list-ch.html', {'chvoclist':chvoclist})
	
def listger(request):
	gervoclist = Gervoc.objects.all()
	return render(request, 'chatbot/list-ger.html', {'gervoclist':gervoclist})
	
# Views for viewing individual words

def vocsarab(request):
	return render(request,'chatbot/vocs-arab.html')
	
def vocsch(request):
	return render(request,'chatbot/vocs-ch.html')
	
def vocsger(request):
	return render(request,'chatbot/vocs-ger.html')
	
# Views for the vocabulary tests

def testarab(request):
	arabvoclist = Arabvoc.objects.all()
	return render(request,'chatbot/test-arab.html',{'arabvoclist':arabvoclist})
	
def testch(request):
	return render(request,'chatbot/test-ch.html')
	
def testger(request):
	return render(request,'chatbot/test-ger.html')
