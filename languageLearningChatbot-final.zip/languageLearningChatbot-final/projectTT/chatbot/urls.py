from django.urls import path
from . import views

# create path for the methods in views.py

app_name = 'chatbot'
urlpatterns = [
	# the index page
	path('', views.index, name='index'),
	# language selection page
	path('languages.html/',views.languages, name='languages'),
	# page for each language
	path('languages.html/arabic.html', views.arabic, name='arabic'),
	path('languages.html/chinese.html/', views.chinese, name='chinese'),
	path('languages.html/german.html/', views.german, name='german'),
	# vocabulary list pages
	path('languages.html/list-arab.html', views.listarab, name='listarab'),
	path('languages.html/chinese.html/list-ch.html', views.listch, name='listch'),
	path('languages.html/german.html/list-ger.html', views.listger, name='listger'),
	# vocabulary cards pages
	path('languages.html/vocs-arab.html', views.vocsarab, name='vocsarab'),
	path('languages.html/chinese.html/vocs-ch.html', views.vocsch, name='vocsch'),
	path('languages.html/german.html/vocs-ger.html', views.vocsger, name='vocsger'),
	# vocabulary test pages
	path('languages.html/test-arab.html', views.testarab, name='testarab'),
	path('languages.html/chinese.html/test-ch.html', views.testch, name='testch'),
	path('languages.html/german.html/test-ger.html', views.testger, name='testger'),
]
