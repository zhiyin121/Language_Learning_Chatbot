/*Sylvia's code
function hide() {
	var divelement = document.getElementById(firstDiv);
	divelement.style.display = 'block' ;
}    
function show() {
	var divelement = document.getElementById(firstDiv);
	divelement.style.display = 'none' ;
}
    
document.getElementById("nextword").onclick = function() {document.getElementById("firstDiv").innerHTML = "lo" ;
*/	
	
var wordlist = ['test', 'test1','test2'];
var num=0;

function next(){
	var cards = getElementById('words');
	num ++;
	if (num >= wordlist.length){
		num = 0;
	}
	words.src = wordlist[num];
}

function prev(){
	var cards = getElementById('words);
	num--;
	if (num <0){
		num = wordlist.length-1;
	}
	words.src = wordlist[num];
}
