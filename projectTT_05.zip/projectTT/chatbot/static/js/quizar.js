
var questions = [
     {
           prompt: "What does يناير mean?\n(a) January\n\ (b) February\n(c) March",
           answer: "a"
     },
     {
          prompt: "What does فستان mean?\n(a) shirt\n\ (b) dress\n(c) shoes",
          answer: "b"
     },
     {
          prompt: "What does ممحاة mean?\n(a) pencil\n\ (b) sharpener\n(c) eraser",
          answer: "c"
     }
];
var score = 0;


for(var i = 0; i < questions.length; i++){
     var response = window.prompt(questions[i].prompt);
     if(response == questions[i].answer){
          score++;
          alert("Correct!");
     } else {
          alert("WRONG!");
     }
}
alert("you got " + score + "/" + questions.length);










